package com.stillmantowing.earnings.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.stillmantowing.earnings.data.DailySummaryEntity
import com.stillmantowing.earnings.ui.theme.*
import com.stillmantowing.earnings.viewmodel.MainViewModel
import com.stillmantowing.earnings.viewmodel.WeeklyState

@Composable
fun ReportsScreen(
    viewModel: MainViewModel,
    onViewDay: (String) -> Unit
) {
    val weekly by viewModel.weeklyState.collectAsState()
    val summaries by viewModel.allSummaries.collectAsState()
    var tab by remember { mutableIntStateOf(0) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkGray)
    ) {
        Text(
            "Reports",
            color = White,
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(16.dp)
        )

        TabRow(
            selectedTabIndex = tab,
            containerColor = MediumGray,
            contentColor = Green
        ) {
            Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("This Week") })
            Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("Past Days") })
        }

        when (tab) {
            0 -> WeeklyReport(weekly, viewModel)
            1 -> PastDaysList(summaries, viewModel, onViewDay)
        }
    }
}

@Composable
private fun WeeklyReport(weekly: WeeklyState, viewModel: MainViewModel) {
    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text(weekly.weekLabel, color = LightGray, fontSize = 14.sp)
            Spacer(modifier = Modifier.height(8.dp))
        }

        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = CardGray),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    ReportRow("Total Revenue", viewModel.formatCurrency(weekly.totalRevenue), highlight = true)
                    ReportRow("Total Calls", weekly.totalCalls.toString())
                    ReportRow("Driver Pay", viewModel.formatCurrency(weekly.totalDriverPay))
                    ReportRow("Company Remainder", viewModel.formatCurrency(weekly.totalCompany), green = true)
                    ReportRow("Avg per Active Day", viewModel.formatCurrency(weekly.avgPerDay))
                    ReportRow("Days Goal Reached", "${weekly.daysReachedGoal} / 7")
                }
            }
        }

        item {
            Text("Daily Breakdown", color = White, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
        }

        items(weekly.dailyBreakdown) { day ->
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = if (day.goalReached) GreenDark.copy(alpha = 0.25f) else CardGray
                ),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(day.dayName, color = White, fontWeight = FontWeight.SemiBold)
                        Text(
                            if (day.calls > 0) "${day.calls} call${if (day.calls != 1) "s" else ""}" else "No calls",
                            color = LightGray,
                            fontSize = 12.sp
                        )
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            viewModel.formatCurrency(day.revenue),
                            color = if (day.goalReached) Green else White,
                            fontWeight = FontWeight.Bold
                        )
                        if (day.goalReached) {
                            Text("Goal ✓", color = Green, fontSize = 11.sp)
                        }
                    }
                }
            }
        }
        item { Spacer(modifier = Modifier.height(80.dp)) }
    }
}

@Composable
private fun PastDaysList(
    summaries: List<DailySummaryEntity>,
    viewModel: MainViewModel,
    onViewDay: (String) -> Unit
) {
    if (summaries.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("No closed-out days yet.", color = LightGray)
        }
    } else {
        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(summaries, key = { it.dayKey }) { summary ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onViewDay(summary.dayKey) },
                    colors = CardDefaults.cardColors(containerColor = CardGray),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                viewModel.formatDayKey(summary.dayKey),
                                color = White,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                "${summary.callCount} calls • ${"%.0f".format(summary.goalPercent)}% of goal",
                                color = LightGray,
                                fontSize = 12.sp
                            )
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                viewModel.formatCurrency(summary.totalRevenue),
                                color = if (summary.goalReached) Green else White,
                                fontWeight = FontWeight.Bold
                            )
                            Icon(
                                Icons.Default.ChevronRight,
                                contentDescription = null,
                                tint = LightGray
                            )
                        }
                    }
                }
            }
            item { Spacer(modifier = Modifier.height(80.dp)) }
        }
    }
}

@Composable
private fun ReportRow(
    label: String,
    value: String,
    highlight: Boolean = false,
    green: Boolean = false
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, color = LightGray, fontSize = 14.sp)
        Text(
            value,
            color = when {
                highlight -> White
                green -> Green
                else -> White
            },
            fontWeight = if (highlight || green) FontWeight.Bold else FontWeight.Normal,
            fontSize = if (highlight) 18.sp else 14.sp
        )
    }
}
