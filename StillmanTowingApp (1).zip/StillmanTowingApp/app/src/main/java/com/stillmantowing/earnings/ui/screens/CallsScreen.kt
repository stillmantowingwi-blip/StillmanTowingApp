package com.stillmantowing.earnings.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.stillmantowing.earnings.data.CallEntity
import com.stillmantowing.earnings.ui.theme.*
import com.stillmantowing.earnings.viewmodel.MainViewModel

@Composable
fun CallsScreen(
    viewModel: MainViewModel,
    onAddCall: () -> Unit,
    onEditCall: (CallEntity) -> Unit
) {
    val calls by viewModel.allCalls.collectAsState()
    val todayKey = viewModel.todayKey
    val todayCalls = calls.filter { it.dayKey == todayKey }
    val pastCalls = calls.filter { it.dayKey != todayKey }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkGray)
    ) {
        // Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("All Calls", color = White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Text("${calls.size} total", color = LightGray, fontSize = 13.sp)
            }
            FloatingActionButton(
                onClick = onAddCall,
                containerColor = Green,
                contentColor = Black,
                modifier = Modifier.size(48.dp)
            ) {
                Icon(Icons.Default.Add, contentDescription = "Add Call")
            }
        }

        if (calls.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("No calls yet. Tap + to add one.", color = LightGray)
            }
        } else {
            LazyColumn(
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (todayCalls.isNotEmpty()) {
                    item {
                        Text("Today", color = Green, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                        Spacer(modifier = Modifier.height(4.dp))
                    }
                    items(todayCalls, key = { it.id }) { call ->
                        CallCard(call, viewModel, onEditCall)
                    }
                }
                if (pastCalls.isNotEmpty()) {
                    item {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("Previous Days", color = LightGray, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                        Spacer(modifier = Modifier.height(4.dp))
                    }
                    items(pastCalls, key = { it.id }) { call ->
                        CallCard(call, viewModel, onEditCall)
                    }
                }
                item { Spacer(modifier = Modifier.height(80.dp)) }
            }
        }
    }
}

@Composable
private fun CallCard(
    call: CallEntity,
    viewModel: MainViewModel,
    onEdit: (CallEntity) -> Unit
) {
    val driverPay = call.amount * (call.driverPayPercent / 100.0)
    val company = call.amount - driverPay

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onEdit(call) },
        colors = CardDefaults.cardColors(containerColor = CardGray),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    viewModel.formatCurrency(call.amount),
                    color = White,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    viewModel.formatDateTime(call.timestamp),
                    color = LightGray,
                    fontSize = 12.sp
                )
            }
            Spacer(modifier = Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                Text("Driver: ${viewModel.formatCurrency(driverPay)}", color = Orange, fontSize = 13.sp)
                Text("Company: ${viewModel.formatCurrency(company)}", color = Green, fontSize = 13.sp)
            }
            if (call.jobNumber.isNotBlank() || call.customerName.isNotBlank()) {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    listOfNotNull(
                        call.jobNumber.takeIf { it.isNotBlank() }?.let { "Job #$it" },
                        call.customerName.takeIf { it.isNotBlank() }
                    ).joinToString(" • "),
                    color = LightGray,
                    fontSize = 13.sp
                )
            }
            if (call.vehicleInfo.isNotBlank()) {
                Text(call.vehicleInfo, color = LightGray, fontSize = 12.sp)
            }
            if (call.isClosedOut) {
                Spacer(modifier = Modifier.height(4.dp))
                Text("Closed out", color = Green.copy(alpha = 0.7f), fontSize = 11.sp)
            }
        }
    }
}
