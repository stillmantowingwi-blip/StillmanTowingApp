package com.stillmantowing.earnings.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.doublePreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "settings")

class SettingsRepository(private val context: Context) {
    private val businessNameKey = stringPreferencesKey("business_name")
    private val dailyGoalKey = doublePreferencesKey("daily_goal")
    private val driverPayPercentKey = doublePreferencesKey("driver_pay_percent")

    val businessName: Flow<String> = context.dataStore.data.map { prefs ->
        prefs[businessNameKey] ?: "Stillman Towing LLC"
    }

    val dailyGoal: Flow<Double> = context.dataStore.data.map { prefs ->
        prefs[dailyGoalKey] ?: 450.0
    }

    val driverPayPercent: Flow<Double> = context.dataStore.data.map { prefs ->
        prefs[driverPayPercentKey] ?: 20.0
    }

    suspend fun setBusinessName(name: String) {
        context.dataStore.edit { it[businessNameKey] = name }
    }

    suspend fun setDailyGoal(goal: Double) {
        context.dataStore.edit { it[dailyGoalKey] = goal }
    }

    suspend fun setDriverPayPercent(percent: Double) {
        context.dataStore.edit { it[driverPayPercentKey] = percent }
    }
}
