package com.stillmantowing.earnings.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.stillmantowing.earnings.data.CallEntity
import com.stillmantowing.earnings.ui.theme.*
import com.stillmantowing.earnings.viewmodel.MainViewModel
import java.time.Instant
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddCallScreen(
    viewModel: MainViewModel,
    existingCall: CallEntity? = null,
    onBack: () -> Unit,
    onSaved: () -> Unit
) {
    var amountText by remember { mutableStateOf(existingCall?.amount?.toString() ?: "") }
    var jobNumber by remember { mutableStateOf(existingCall?.jobNumber ?: "") }
    var customerName by remember { mutableStateOf(existingCall?.customerName ?: "") }
    var vehicleInfo by remember { mutableStateOf(existingCall?.vehicleInfo ?: "") }
    var notes by remember { mutableStateOf(existingCall?.notes ?: "") }
    var error by remember { mutableStateOf<String?>(null) }

    val isEdit = existingCall != null
    val percent = viewModel.dashboard.value.driverPayPercent
    val amount = amountText.toDoubleOrNull() ?: 0.0
    val driverPay = amount * (percent / 100.0)
    val company = amount - driverPay

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        if (isEdit) "Edit Call" else "Add New Call",
                        color = White,
                        fontWeight = FontWeight.Bold
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MediumGray)
            )
        },
        containerColor = DarkGray
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            // Amount - required
            OutlinedTextField(
                value = amountText,
                onValueChange = {
                    amountText = it.filter { c -> c.isDigit() || c == '.' }
                    error = null
                },
                label = { Text("Call Amount ($)") },
                placeholder = { Text("e.g. 100.00") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                colors = textFieldColors(),
                isError = error != null
            )
            if (error != null) {
                Text(error!!, color = Red, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp))
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Live calculation preview
            if (amount > 0) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = CardGray),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Automatic Split", color = LightGray, fontSize = 13.sp)
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Driver Pay (${percent.toInt()}%)", color = LightGray)
                            Text(viewModel.formatCurrency(driverPay), color = Orange, fontWeight = FontWeight.SemiBold)
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Company Keeps", color = LightGray)
                            Text(viewModel.formatCurrency(company), color = Green, fontWeight = FontWeight.Bold)
                        }
                    }
                }
                Spacer(modifier = Modifier.height(16.dp))
            }

            OutlinedTextField(
                value = jobNumber,
                onValueChange = { jobNumber = it },
                label = { Text("Job Number (optional)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                colors = textFieldColors()
            )
            Spacer(modifier = Modifier.height(12.dp))

            OutlinedTextField(
                value = customerName,
                onValueChange = { customerName = it },
                label = { Text("Motor Club / Customer (optional)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                colors = textFieldColors()
            )
            Spacer(modifier = Modifier.height(12.dp))

            OutlinedTextField(
                value = vehicleInfo,
                onValueChange = { vehicleInfo = it },
                label = { Text("Vehicle Year / Make / Model (optional)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                colors = textFieldColors()
            )
            Spacer(modifier = Modifier.height(12.dp))

            OutlinedTextField(
                value = notes,
                onValueChange = { notes = it },
                label = { Text("Notes (optional)") },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(100.dp),
                colors = textFieldColors()
            )
            Spacer(modifier = Modifier.height(12.dp))

            // Date/time display
            val ts = existingCall?.timestamp ?: System.currentTimeMillis()
            Text(
                "Date & Time: ${viewModel.formatDateTime(ts)}",
                color = LightGray,
                fontSize = 14.sp
            )

            Spacer(modifier = Modifier.height(28.dp))

            Button(
                onClick = {
                    val amt = amountText.toDoubleOrNull()
                    if (amt == null || amt <= 0) {
                        error = "Enter a valid amount greater than 0"
                        return@Button
                    }
                    if (isEdit && existingCall != null) {
                        viewModel.updateCall(
                            existingCall.copy(
                                amount = amt,
                                jobNumber = jobNumber,
                                customerName = customerName,
                                vehicleInfo = vehicleInfo,
                                notes = notes
                            )
                        )
                    } else {
                        viewModel.addCall(amt, jobNumber, customerName, vehicleInfo, notes)
                    }
                    onSaved()
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Green),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text(
                    if (isEdit) "UPDATE CALL" else "SAVE CALL",
                    color = Black,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            if (isEdit) {
                Spacer(modifier = Modifier.height(12.dp))
                OutlinedButton(
                    onClick = {
                        existingCall?.let {
                            viewModel.deleteCall(it)
                            onSaved()
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Red),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("DELETE CALL", fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }
}

@Composable
fun textFieldColors() = OutlinedTextFieldDefaults.colors(
    focusedTextColor = White,
    unfocusedTextColor = White,
    focusedBorderColor = Green,
    unfocusedBorderColor = LightGray.copy(alpha = 0.4f),
    focusedLabelColor = Green,
    unfocusedLabelColor = LightGray,
    cursorColor = Green,
    focusedContainerColor = MediumGray,
    unfocusedContainerColor = MediumGray
)
