package com.stillmantowing.earnings.data

import android.content.Context
import kotlinx.coroutines.flow.Flow
import java.time.DayOfWeek
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.time.temporal.TemporalAdjusters

class Repository(context: Context) {
    private val db = AppDatabase.getInstance(context)
    private val callDao = db.callDao()
    private val summaryDao = db.dailySummaryDao()
    private val expenseDao = db.expenseDao()
    val settings = SettingsRepository(context)

    private val zone = ZoneId.systemDefault()
    private val dayFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd")

    fun todayKey(): String = LocalDate.now(zone).format(dayFormatter)

    fun dayKeyFromMillis(millis: Long): String =
        Instant.ofEpochMilli(millis).atZone(zone).toLocalDate().format(dayFormatter)

    // Calls
    fun getAllCalls(): Flow<List<CallEntity>> = callDao.getAllCalls()
    fun getCallsForDay(dayKey: String): Flow<List<CallEntity>> = callDao.getCallsForDay(dayKey)
    suspend fun getCallsForDayOnce(dayKey: String) = callDao.getCallsForDayOnce(dayKey)
    suspend fun getCallById(id: Long) = callDao.getCallById(id)
    suspend fun insertCall(call: CallEntity) = callDao.insert(call)
    suspend fun updateCall(call: CallEntity) = callDao.update(call)
    suspend fun deleteCall(call: CallEntity) = callDao.delete(call)

    // Summaries
    fun getAllSummaries(): Flow<List<DailySummaryEntity>> = summaryDao.getAllSummaries()
    suspend fun getSummary(dayKey: String) = summaryDao.getSummary(dayKey)
    suspend fun insertSummary(summary: DailySummaryEntity) = summaryDao.insert(summary)

    // Expenses
    fun getAllExpenses(): Flow<List<ExpenseEntity>> = expenseDao.getAllExpenses()
    fun getExpensesForDay(dayKey: String): Flow<List<ExpenseEntity>> = expenseDao.getExpensesForDay(dayKey)
    suspend fun insertExpense(expense: ExpenseEntity) = expenseDao.insert(expense)
    suspend fun updateExpense(expense: ExpenseEntity) = expenseDao.update(expense)
    suspend fun deleteExpense(expense: ExpenseEntity) = expenseDao.delete(expense)
    suspend fun getExpensesBetween(start: Long, end: Long) = expenseDao.getExpensesBetween(start, end)

    // Close out day
    suspend fun closeOutDay(dayKey: String, goal: Double) {
        val calls = callDao.getCallsForDayOnce(dayKey)
        if (calls.isEmpty()) return

        val totalRevenue = calls.sumOf { it.amount }
        val totalDriverPay = calls.sumOf { it.amount * (it.driverPayPercent / 100.0) }
        val companyRemainder = totalRevenue - totalDriverPay
        val goalPercent = if (goal > 0) (totalRevenue / goal) * 100.0 else 0.0
        val goalReached = totalRevenue >= goal

        val summary = DailySummaryEntity(
            dayKey = dayKey,
            totalRevenue = totalRevenue,
            callCount = calls.size,
            totalDriverPay = totalDriverPay,
            companyRemainder = companyRemainder,
            goalPercent = goalPercent,
            goalReached = goalReached,
            closedAt = System.currentTimeMillis()
        )
        summaryDao.insert(summary)
        callDao.markDayClosed(dayKey)
    }

    // Week helpers (Monday–Sunday)
    fun currentWeekRange(): Pair<LocalDate, LocalDate> {
        val today = LocalDate.now(zone)
        val monday = today.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
        val sunday = monday.plusDays(6)
        return monday to sunday
    }

    fun weekRangeFor(date: LocalDate): Pair<LocalDate, LocalDate> {
        val monday = date.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
        val sunday = monday.plusDays(6)
        return monday to sunday
    }

    suspend fun getCallsForWeek(monday: LocalDate, sunday: LocalDate): List<CallEntity> {
        val start = monday.atStartOfDay(zone).toInstant().toEpochMilli()
        val end = sunday.plusDays(1).atStartOfDay(zone).toInstant().toEpochMilli()
        return callDao.getCallsBetweenOnce(start, end)
    }

    suspend fun getSummariesForWeek(monday: LocalDate, sunday: LocalDate): List<DailySummaryEntity> {
        return summaryDao.getSummariesBetween(
            monday.format(dayFormatter),
            sunday.format(dayFormatter)
        )
    }
}
