package com.stillmantowing.earnings.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.stillmantowing.earnings.ui.theme.*
import com.stillmantowing.earnings.viewmodel.DashboardState
import com.stillmantowing.earnings.viewmodel.MainViewModel

@Composable
fun DashboardScreen(
    state: DashboardState,
    viewModel: MainViewModel,
    onAddCall: () -> Unit,
    onCloseOut: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkGray)
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        // Header
        Text(
            text = state.businessName,
            color = White,
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = "Daily Earnings Dashboard",
            color = LightGray,
            fontSize = 14.sp
        )
        Spacer(modifier = Modifier.height(20.dp))

        // Goal Progress Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = CardGray),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Daily Goal", color = LightGray, fontSize = 14.sp)
                    Text(
                        viewModel.formatCurrency(state.dailyGoal),
                        color = White,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
                Spacer(modifier = Modifier.height(12.dp))

                // Large revenue number
                Text(
                    text = viewModel.formatCurrency(state.todayRevenue),
                    color = if (state.goalReached) Green else White,
                    fontSize = 42.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.fillMaxWidth(),
                    textAlign = TextAlign.Center
                )
                Text(
                    text = if (state.goalReached) "GOAL REACHED!" else "earned today",
                    color = if (state.goalReached) Green else LightGray,
                    fontSize = 14.sp,
                    modifier = Modifier.fillMaxWidth(),
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(16.dp))

                // Progress bar
                val progressColor = if (state.goalReached) Green else AccentGreen
                LinearProgressIndicator(
                    progress = { state.progress.coerceAtMost(1f) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(16.dp)
                        .clip(RoundedCornerShape(8.dp)),
                    color = progressColor,
                    trackColor = MediumGray
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        "${(state.progress * 100).toInt()}%",
                        color = progressColor,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                    if (!state.goalReached) {
                        Text(
                            "${viewModel.formatCurrency(state.remaining)} to go",
                            color = LightGray,
                            fontSize = 14.sp
                        )
                    } else {
                        Text(
                            "Exceeded!",
                            color = Green,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Stats row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            StatCard(
                title = "Calls",
                value = state.todayCalls.toString(),
                modifier = Modifier.weight(1f)
            )
            StatCard(
                title = "Driver Pay",
                value = viewModel.formatCurrency(state.todayDriverPay),
                subtitle = "${state.driverPayPercent.toInt()}%",
                modifier = Modifier.weight(1f)
            )
        }
        Spacer(modifier = Modifier.height(12.dp))
        StatCard(
            title = "Company Remainder",
            value = viewModel.formatCurrency(state.todayCompany),
            modifier = Modifier.fillMaxWidth(),
            highlight = true
        )

        Spacer(modifier = Modifier.height(24.dp))

        // Add Call button
        Button(
            onClick = onAddCall,
            modifier = Modifier
                .fillMaxWidth()
                .height(60.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Green),
            shape = RoundedCornerShape(12.dp)
        ) {
            Icon(Icons.Default.Add, contentDescription = null, tint = Black)
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                "+ ADD CALL",
                color = Black,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Close Out Day button
        if (!state.isDayClosed) {
            OutlinedButton(
                onClick = onCloseOut,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Orange),
                border = ButtonDefaults.outlinedButtonBorder.copy(
                    width = 1.5.dp
                ),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Default.CheckCircle, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    "CLOSE OUT DAY",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
        } else {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(CardGray, RoundedCornerShape(12.dp))
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                Icon(Icons.Default.Lock, contentDescription = null, tint = Green)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    "Day Closed Out",
                    color = Green,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))
    }
}

@Composable
private fun StatCard(
    title: String,
    value: String,
    subtitle: String? = null,
    modifier: Modifier = Modifier,
    highlight: Boolean = false
) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(
            containerColor = if (highlight) GreenDark.copy(alpha = 0.3f) else CardGray
        ),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(title, color = LightGray, fontSize = 13.sp)
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                value,
                color = if (highlight) AccentGreen else White,
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold
            )
            if (subtitle != null) {
                Text(subtitle, color = LightGray, fontSize = 12.sp)
            }
        }
    }
}
