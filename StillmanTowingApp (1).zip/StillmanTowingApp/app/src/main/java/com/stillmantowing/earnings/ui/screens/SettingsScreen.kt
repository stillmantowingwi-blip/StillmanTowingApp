package com.stillmantowing.earnings.ui.screens

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.stillmantowing.earnings.ui.theme.*
import com.stillmantowing.earnings.viewmodel.MainViewModel

@Composable
fun SettingsScreen(viewModel: MainViewModel) {
    val dashboard by viewModel.dashboard.collectAsState()
    val context = LocalContext.current

    var businessName by remember(dashboard.businessName) { mutableStateOf(dashboard.businessName) }
    var goalText by remember(dashboard.dailyGoal) { mutableStateOf(dashboard.dailyGoal.toString()) }
    var percentText by remember(dashboard.driverPayPercent) {
        mutableStateOf(dashboard.driverPayPercent.toString())
    }
    var savedMsg by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkGray)
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Text("Settings", color = White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(20.dp))

        Card(
            colors = CardDefaults.cardColors(containerColor = CardGray),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Business Name", color = LightGray, fontSize = 13.sp)
                Spacer(modifier = Modifier.height(6.dp))
                OutlinedTextField(
                    value = businessName,
                    onValueChange = { businessName = it },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    colors = textFieldColors()
                )
                Spacer(modifier = Modifier.height(16.dp))

                Text("Daily Revenue Goal ($)", color = LightGray, fontSize = 13.sp)
                Spacer(modifier = Modifier.height(6.dp))
                OutlinedTextField(
                    value = goalText,
                    onValueChange = { goalText = it.filter { c -> c.isDigit() || c == '.' } },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier.fillMaxWidth(),
                    colors = textFieldColors()
                )
                Spacer(modifier = Modifier.height(16.dp))

                Text("Driver Pay Percentage (%)", color = LightGray, fontSize = 13.sp)
                Spacer(modifier = Modifier.height(6.dp))
                OutlinedTextField(
                    value = percentText,
                    onValueChange = { percentText = it.filter { c -> c.isDigit() || c == '.' } },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier.fillMaxWidth(),
                    colors = textFieldColors()
                )
                Text(
                    "Example: 20 means driver gets 20% of each call",
                    color = LightGray.copy(alpha = 0.7f),
                    fontSize = 12.sp,
                    modifier = Modifier.padding(top = 4.dp)
                )

                Spacer(modifier = Modifier.height(20.dp))
                Button(
                    onClick = {
                        viewModel.setBusinessName(businessName.trim().ifBlank { "Stillman Towing LLC" })
                        goalText.toDoubleOrNull()?.let { if (it > 0) viewModel.setDailyGoal(it) }
                        percentText.toDoubleOrNull()?.let {
                            if (it in 0.0..100.0) viewModel.setDriverPayPercent(it)
                        }
                        savedMsg = "Settings saved"
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Green),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text("SAVE SETTINGS", color = Black, fontWeight = FontWeight.Bold)
                }
                if (savedMsg != null) {
                    Text(savedMsg!!, color = Green, fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp))
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Export
        Card(
            colors = CardDefaults.cardColors(containerColor = CardGray),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Backup & Export", color = White, fontWeight = FontWeight.SemiBold)
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    "Export all calls, daily summaries, and expenses to a CSV file you can open in Excel.",
                    color = LightGray,
                    fontSize = 13.sp
                )
                Spacer(modifier = Modifier.height(12.dp))
                Button(
                    onClick = {
                        val uri = viewModel.exportToCsv(context)
                        if (uri != null) {
                            val share = Intent(Intent.ACTION_SEND).apply {
                                type = "text/csv"
                                putExtra(Intent.EXTRA_STREAM, uri)
                                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            }
                            context.startActivity(Intent.createChooser(share, "Export Stillman Towing data"))
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MediumGray),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(Icons.Default.Share, contentDescription = null, tint = White)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("EXPORT TO CSV", color = White, fontWeight = FontWeight.SemiBold)
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        Text(
            "Stillman Towing LLC Earnings Tracker v1.0.0\nData is stored locally on this device.\nNo internet required.",
            color = LightGray.copy(alpha = 0.6f),
            fontSize = 12.sp,
            modifier = Modifier.padding(horizontal = 4.dp)
        )
        Spacer(modifier = Modifier.height(80.dp))
    }
}
