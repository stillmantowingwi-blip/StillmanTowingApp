package com.stillmantowing.earnings.viewmodel

import android.app.Application
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.core.content.FileProvider
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.stillmantowing.earnings.data.CallEntity
import com.stillmantowing.earnings.data.DailySummaryEntity
import com.stillmantowing.earnings.data.ExpenseEntity
import com.stillmantowing.earnings.data.Repository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.File
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

data class DashboardState(
    val todayRevenue: Double = 0.0,
    val todayCalls: Int = 0,
    val todayDriverPay: Double = 0.0,
    val todayCompany: Double = 0.0,
    val dailyGoal: Double = 450.0,
    val remaining: Double = 450.0,
    val progress: Float = 0f,
    val goalReached: Boolean = false,
    val businessName: String = "Stillman Towing LLC",
    val driverPayPercent: Double = 20.0,
    val isDayClosed: Boolean = false
)

data class WeeklyState(
    val totalRevenue: Double = 0.0,
    val totalCalls: Int = 0,
    val totalDriverPay: Double = 0.0,
    val totalCompany: Double = 0.0,
    val avgPerDay: Double = 0.0,
    val daysReachedGoal: Int = 0,
    val dailyBreakdown: List<DayBreakdown> = emptyList(),
    val weekLabel: String = ""
)

data class DayBreakdown(
    val dayName: String,
    val dayKey: String,
    val revenue: Double,
    val calls: Int,
    val driverPay: Double,
    val company: Double,
    val goalReached: Boolean
)

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val repo = Repository(application)

    private val zone = ZoneId.systemDefault()
    private val dayFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd")
    private val displayFormatter = DateTimeFormatter.ofPattern("EEE, MMM d", Locale.US)
    private val fullDateFormatter = DateTimeFormatter.ofPattern("MMMM d, yyyy", Locale.US)

    val todayKey = repo.todayKey()

    val callsToday = repo.getCallsForDay(todayKey)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allCalls = repo.getAllCalls()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allSummaries = repo.getAllSummaries()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allExpenses = repo.getAllExpenses()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _selectedDayKey = MutableStateFlow(todayKey)
    val selectedDayKey: StateFlow<String> = _selectedDayKey

    val selectedDayCalls = combine(_selectedDayKey, allCalls) { key, calls ->
        calls.filter { it.dayKey == key }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val dashboard: StateFlow<DashboardState> = combine(
        callsToday,
        repo.settings.dailyGoal,
        repo.settings.businessName,
        repo.settings.driverPayPercent,
        allSummaries
    ) { calls, goal, name, percent, summaries ->
        val revenue = calls.sumOf { it.amount }
        val driverPay = calls.sumOf { it.amount * (it.driverPayPercent / 100.0) }
        val company = revenue - driverPay
        val remaining = (goal - revenue).coerceAtLeast(0.0)
        val progress = if (goal > 0) (revenue / goal).toFloat().coerceIn(0f, 1.5f) else 0f
        val closed = summaries.any { it.dayKey == todayKey }
        DashboardState(
            todayRevenue = revenue,
            todayCalls = calls.size,
            todayDriverPay = driverPay,
            todayCompany = company,
            dailyGoal = goal,
            remaining = remaining,
            progress = progress,
            goalReached = revenue >= goal,
            businessName = name,
            driverPayPercent = percent,
            isDayClosed = closed
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), DashboardState())

    private val _weeklyState = MutableStateFlow(WeeklyState())
    val weeklyState: StateFlow<WeeklyState> = _weeklyState

    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message

    init {
        refreshWeekly()
    }

    fun refreshWeekly(weekStart: LocalDate? = null) {
        viewModelScope.launch {
            val (monday, sunday) = if (weekStart != null) {
                repo.weekRangeFor(weekStart)
            } else {
                repo.currentWeekRange()
            }
            val calls = repo.getCallsForWeek(monday, sunday)
            val summaries = repo.getSummariesForWeek(monday, sunday)

            val byDay = (0..6).map { offset ->
                val date = monday.plusDays(offset.toLong())
                val key = date.format(dayFormatter)
                val dayCalls = calls.filter { it.dayKey == key }
                val revenue = dayCalls.sumOf { it.amount }
                val driverPay = dayCalls.sumOf { it.amount * (it.driverPayPercent / 100.0) }
                DayBreakdown(
                    dayName = date.dayOfWeek.name.take(3).lowercase().replaceFirstChar { it.uppercase() },
                    dayKey = key,
                    revenue = revenue,
                    calls = dayCalls.size,
                    driverPay = driverPay,
                    company = revenue - driverPay,
                    goalReached = revenue >= (dashboard.value.dailyGoal)
                )
            }

            val totalRev = calls.sumOf { it.amount }
            val totalDriver = calls.sumOf { it.amount * (it.driverPayPercent / 100.0) }
            val daysWithActivity = byDay.count { it.calls > 0 }
            val avg = if (daysWithActivity > 0) totalRev / daysWithActivity else 0.0

            _weeklyState.value = WeeklyState(
                totalRevenue = totalRev,
                totalCalls = calls.size,
                totalDriverPay = totalDriver,
                totalCompany = totalRev - totalDriver,
                avgPerDay = avg,
                daysReachedGoal = byDay.count { it.goalReached },
                dailyBreakdown = byDay,
                weekLabel = "${monday.format(DateTimeFormatter.ofPattern("MMM d"))} – ${sunday.format(DateTimeFormatter.ofPattern("MMM d, yyyy"))}"
            )
        }
    }

    fun addCall(
        amount: Double,
        jobNumber: String,
        customerName: String,
        vehicleInfo: String,
        notes: String,
        timestamp: Long = System.currentTimeMillis()
    ) {
        viewModelScope.launch {
            val percent = dashboard.value.driverPayPercent
            val call = CallEntity(
                amount = amount,
                jobNumber = jobNumber.trim(),
                customerName = customerName.trim(),
                vehicleInfo = vehicleInfo.trim(),
                notes = notes.trim(),
                timestamp = timestamp,
                driverPayPercent = percent,
                dayKey = repo.dayKeyFromMillis(timestamp)
            )
            repo.insertCall(call)
            _message.value = "Call saved: $${"%.2f".format(amount)}"
            refreshWeekly()
        }
    }

    fun updateCall(call: CallEntity) {
        viewModelScope.launch {
            repo.updateCall(call.copy(dayKey = repo.dayKeyFromMillis(call.timestamp)))
            _message.value = "Call updated"
            refreshWeekly()
        }
    }

    fun deleteCall(call: CallEntity) {
        viewModelScope.launch {
            repo.deleteCall(call)
            _message.value = "Call deleted"
            refreshWeekly()
        }
    }

    fun closeOutDay() {
        viewModelScope.launch {
            val goal = dashboard.value.dailyGoal
            repo.closeOutDay(todayKey, goal)
            _message.value = "Day closed out successfully"
            refreshWeekly()
        }
    }

    fun addExpense(amount: Double, category: String, description: String, timestamp: Long = System.currentTimeMillis()) {
        viewModelScope.launch {
            val expense = ExpenseEntity(
                amount = amount,
                category = category,
                description = description.trim(),
                timestamp = timestamp,
                dayKey = repo.dayKeyFromMillis(timestamp)
            )
            repo.insertExpense(expense)
            _message.value = "Expense saved"
        }
    }

    fun deleteExpense(expense: ExpenseEntity) {
        viewModelScope.launch {
            repo.deleteExpense(expense)
            _message.value = "Expense deleted"
        }
    }

    fun setDailyGoal(goal: Double) {
        viewModelScope.launch { repo.settings.setDailyGoal(goal) }
    }

    fun setDriverPayPercent(percent: Double) {
        viewModelScope.launch { repo.settings.setDriverPayPercent(percent) }
    }

    fun setBusinessName(name: String) {
        viewModelScope.launch { repo.settings.setBusinessName(name) }
    }

    fun selectDay(dayKey: String) {
        _selectedDayKey.value = dayKey
    }

    fun clearMessage() {
        _message.value = null
    }

    fun formatCurrency(value: Double): String = "$" + String.format(Locale.US, "%.2f", value)

    fun formatDateTime(millis: Long): String {
        val dt = Instant.ofEpochMilli(millis).atZone(zone)
        return dt.format(DateTimeFormatter.ofPattern("MMM d, yyyy h:mm a", Locale.US))
    }

    fun formatDayKey(dayKey: String): String {
        return try {
            LocalDate.parse(dayKey).format(fullDateFormatter)
        } catch (e: Exception) {
            dayKey
        }
    }

    // Export CSV
    fun exportToCsv(context: Context): Uri? {
        return try {
            val calls = allCalls.value
            val expenses = allExpenses.value
            val summaries = allSummaries.value

            val sb = StringBuilder()
            sb.appendLine("=== CALLS ===")
            sb.appendLine("ID,Date,Amount,DriverPay%,DriverPay,Company,JobNumber,Customer,Vehicle,Notes")
            calls.forEach { c ->
                val driverPay = c.amount * (c.driverPayPercent / 100.0)
                sb.appendLine(
                    "${c.id},${formatDateTime(c.timestamp)},${c.amount},${c.driverPayPercent}," +
                            "${"%.2f".format(driverPay)},${"%.2f".format(c.amount - driverPay)}," +
                            "\"${c.jobNumber}\",\"${c.customerName}\",\"${c.vehicleInfo}\",\"${c.notes}\""
                )
            }
            sb.appendLine()
            sb.appendLine("=== DAILY SUMMARIES ===")
            sb.appendLine("Date,Revenue,Calls,DriverPay,Company,Goal%,GoalReached")
            summaries.forEach { s ->
                sb.appendLine(
                    "${s.dayKey},${s.totalRevenue},${s.callCount},${s.totalDriverPay}," +
                            "${s.companyRemainder},${"%.1f".format(s.goalPercent)},${s.goalReached}"
                )
            }
            sb.appendLine()
            sb.appendLine("=== EXPENSES ===")
            sb.appendLine("ID,Date,Amount,Category,Description")
            expenses.forEach { e ->
                sb.appendLine(
                    "${e.id},${formatDateTime(e.timestamp)},${e.amount},\"${e.category}\",\"${e.description}\""
                )
            }

            val file = File(context.cacheDir, "stillman_towing_export_${System.currentTimeMillis()}.csv")
            file.writeText(sb.toString())
            FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }
}
