package com.stillmantowing.earnings.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Black = Color(0xFF000000)
val DarkGray = Color(0xFF121212)
val MediumGray = Color(0xFF1E1E1E)
val CardGray = Color(0xFF2A2A2A)
val LightGray = Color(0xFFB0B0B0)
val White = Color(0xFFFFFFFF)
val Green = Color(0xFF4CAF50)
val GreenDark = Color(0xFF2E7D32)
val AccentGreen = Color(0xFF69F0AE)
val Red = Color(0xFFE53935)
val Orange = Color(0xFFFFA726)

private val DarkColorScheme = darkColorScheme(
    primary = Green,
    onPrimary = Black,
    secondary = AccentGreen,
    onSecondary = Black,
    background = DarkGray,
    onBackground = White,
    surface = MediumGray,
    onSurface = White,
    surfaceVariant = CardGray,
    onSurfaceVariant = LightGray,
    error = Red,
    onError = White
)

@Composable
fun StillmanTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        content = content
    )
}
