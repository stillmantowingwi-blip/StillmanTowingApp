package com.stillmantowing.earnings.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface CallDao {
    @Query("SELECT * FROM calls ORDER BY timestamp DESC")
    fun getAllCalls(): Flow<List<CallEntity>>

    @Query("SELECT * FROM calls WHERE dayKey = :dayKey ORDER BY timestamp DESC")
    fun getCallsForDay(dayKey: String): Flow<List<CallEntity>>

    @Query("SELECT * FROM calls WHERE dayKey = :dayKey ORDER BY timestamp DESC")
    suspend fun getCallsForDayOnce(dayKey: String): List<CallEntity>

    @Query("SELECT * FROM calls WHERE id = :id")
    suspend fun getCallById(id: Long): CallEntity?

    @Insert
    suspend fun insert(call: CallEntity): Long

    @Update
    suspend fun update(call: CallEntity)

    @Delete
    suspend fun delete(call: CallEntity)

    @Query("UPDATE calls SET isClosedOut = 1 WHERE dayKey = :dayKey")
    suspend fun markDayClosed(dayKey: String)

    @Query("SELECT * FROM calls WHERE timestamp >= :start AND timestamp < :end ORDER BY timestamp DESC")
    fun getCallsBetween(start: Long, end: Long): Flow<List<CallEntity>>

    @Query("SELECT * FROM calls WHERE timestamp >= :start AND timestamp < :end ORDER BY timestamp DESC")
    suspend fun getCallsBetweenOnce(start: Long, end: Long): List<CallEntity>
}

@Dao
interface DailySummaryDao {
    @Query("SELECT * FROM daily_summaries ORDER BY dayKey DESC")
    fun getAllSummaries(): Flow<List<DailySummaryEntity>>

    @Query("SELECT * FROM daily_summaries WHERE dayKey = :dayKey")
    suspend fun getSummary(dayKey: String): DailySummaryEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(summary: DailySummaryEntity)

    @Query("SELECT * FROM daily_summaries WHERE dayKey >= :start AND dayKey <= :end ORDER BY dayKey ASC")
    suspend fun getSummariesBetween(start: String, end: String): List<DailySummaryEntity>
}

@Dao
interface ExpenseDao {
    @Query("SELECT * FROM expenses ORDER BY timestamp DESC")
    fun getAllExpenses(): Flow<List<ExpenseEntity>>

    @Query("SELECT * FROM expenses WHERE dayKey = :dayKey ORDER BY timestamp DESC")
    fun getExpensesForDay(dayKey: String): Flow<List<ExpenseEntity>>

    @Query("SELECT * FROM expenses WHERE timestamp >= :start AND timestamp < :end ORDER BY timestamp DESC")
    suspend fun getExpensesBetween(start: Long, end: Long): List<ExpenseEntity>

    @Insert
    suspend fun insert(expense: ExpenseEntity): Long

    @Update
    suspend fun update(expense: ExpenseEntity)

    @Delete
    suspend fun delete(expense: ExpenseEntity)
}
