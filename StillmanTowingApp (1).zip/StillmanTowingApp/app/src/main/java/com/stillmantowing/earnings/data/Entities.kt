package com.stillmantowing.earnings.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "calls")
data class CallEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val amount: Double,
    val jobNumber: String = "",
    val customerName: String = "",
    val vehicleInfo: String = "",
    val notes: String = "",
    val timestamp: Long,          // epoch millis
    val driverPayPercent: Double, // snapshot of rate at time of call
    val isClosedOut: Boolean = false,
    val dayKey: String            // yyyy-MM-dd for easy grouping
)

@Entity(tableName = "daily_summaries")
data class DailySummaryEntity(
    @PrimaryKey val dayKey: String, // yyyy-MM-dd
    val totalRevenue: Double,
    val callCount: Int,
    val totalDriverPay: Double,
    val companyRemainder: Double,
    val goalPercent: Double,
    val goalReached: Boolean,
    val closedAt: Long
)

@Entity(tableName = "expenses")
data class ExpenseEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val amount: Double,
    val category: String,         // Insurance, Fuel, Repairs, Other
    val description: String = "",
    val timestamp: Long,
    val dayKey: String
)
