package com.stillmantowing.earnings.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.stillmantowing.earnings.data.CallEntity
import com.stillmantowing.earnings.ui.theme.*
import com.stillmantowing.earnings.viewmodel.MainViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DayDetailScreen(
    dayKey: String,
    viewModel: MainViewModel,
    onBack: () -> Unit,
    onEditCall: (CallEntity) -> Unit
) {
    LaunchedEffect(dayKey) {
        viewModel.selectDay(dayKey)
    }
    val calls by viewModel.selectedDayCalls.collectAsState()
    val summaries by viewModel.allSummaries.collectAsState()
    val summary = summaries.find { it.dayKey == dayKey }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        viewModel.formatDayKey(dayKey),
                        color = White,
                        fontWeight = FontWeight.Bold
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MediumGray)
            )
        },
        containerColor = DarkGray
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (summary != null) {
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = CardGray),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text("Daily Summary", color = LightGray, fontSize = 13.sp)
                            Spacer(modifier = Modifier.height(8.dp))
                            SummaryRow("Revenue", viewModel.formatCurrency(summary.totalRevenue), bold = true)
                            SummaryRow("Calls", summary.callCount.toString())
                            SummaryRow("Driver Pay", viewModel.formatCurrency(summary.totalDriverPay))
                            SummaryRow("Company", viewModel.formatCurrency(summary.companyRemainder), green = true)
                            SummaryRow("Goal", "${"%.0f".format(summary.goalPercent)}% ${if (summary.goalReached) "✓" else ""}")
                        }
                    }
                }
            }

            item {
                Text(
                    "Calls (${calls.size})",
                    color = White,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 16.sp
                )
            }

            if (calls.isEmpty()) {
                item {
                    Text("No calls for this day.", color = LightGray)
                }
            } else {
                items(calls, key = { it.id }) { call ->
                    val driverPay = call.amount * (call.driverPayPercent / 100.0)
                    Card(
                        onClick = { onEditCall(call) },
                        colors = CardDefaults.cardColors(containerColor = CardGray),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    viewModel.formatCurrency(call.amount),
                                    color = White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 18.sp
                                )
                                Text(
                                    viewModel.formatDateTime(call.timestamp),
                                    color = LightGray,
                                    fontSize = 12.sp
                                )
                            }
                            Text(
                                "Driver ${viewModel.formatCurrency(driverPay)} • Company ${viewModel.formatCurrency(call.amount - driverPay)}",
                                color = LightGray,
                                fontSize = 13.sp
                            )
                            if (call.customerName.isNotBlank() || call.jobNumber.isNotBlank()) {
                                Text(
                                    listOfNotNull(
                                        call.jobNumber.takeIf { it.isNotBlank() }?.let { "#$it" },
                                        call.customerName.takeIf { it.isNotBlank() }
                                    ).joinToString(" • "),
                                    color = LightGray,
                                    fontSize = 12.sp
                                )
                            }
                        }
                    }
                }
            }
            item { Spacer(modifier = Modifier.height(40.dp)) }
        }
    }
}

@Composable
private fun SummaryRow(label: String, value: String, bold: Boolean = false, green: Boolean = false) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, color = LightGray, fontSize = 14.sp)
        Text(
            value,
            color = if (green) Green else White,
            fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal,
            fontSize = if (bold) 18.sp else 14.sp
        )
    }
}
