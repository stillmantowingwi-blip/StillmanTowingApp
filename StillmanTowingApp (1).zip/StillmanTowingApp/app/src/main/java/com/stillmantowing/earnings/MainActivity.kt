package com.stillmantowing.earnings

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.stillmantowing.earnings.data.CallEntity
import com.stillmantowing.earnings.ui.screens.*
import com.stillmantowing.earnings.ui.theme.*
import com.stillmantowing.earnings.viewmodel.MainViewModel

sealed class Screen(val route: String, val title: String, val icon: ImageVector) {
    data object Dashboard : Screen("dashboard", "Dashboard", Icons.Default.Home)
    data object Calls : Screen("calls", "Calls", Icons.Default.List)
    data object Reports : Screen("reports", "Reports", Icons.Default.Assessment)
    data object Expenses : Screen("expenses", "Expenses", Icons.Default.Receipt)
    data object Settings : Screen("settings", "Settings", Icons.Default.Settings)
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            StillmanTheme {
                StillmanAppRoot()
            }
        }
    }
}

@Composable
fun StillmanAppRoot() {
    val viewModel: MainViewModel = viewModel()
    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route ?: Screen.Dashboard.route

    val bottomScreens = listOf(
        Screen.Dashboard,
        Screen.Calls,
        Screen.Reports,
        Screen.Expenses,
        Screen.Settings
    )
    val showBottomBar = bottomScreens.any { it.route == currentRoute }

    // Snackbar for messages
    val message by viewModel.message.collectAsState()
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(message) {
        message?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearMessage()
        }
    }

    // Close-out confirmation
    var showCloseConfirm by remember { mutableStateOf(false) }

    Scaffold(
        containerColor = DarkGray,
        snackbarHost = { SnackbarHost(snackbarHostState) },
        bottomBar = {
            if (showBottomBar) {
                NavigationBar(
                    containerColor = MediumGray,
                    tonalElevation = 0.dp
                ) {
                    bottomScreens.forEach { screen ->
                        NavigationBarItem(
                            selected = currentRoute == screen.route,
                            onClick = {
                                navController.navigate(screen.route) {
                                    popUpTo(Screen.Dashboard.route) { saveState = true }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            icon = {
                                Icon(screen.icon, contentDescription = screen.title)
                            },
                            label = { Text(screen.title, maxLines = 1) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Green,
                                selectedTextColor = Green,
                                unselectedIconColor = LightGray,
                                unselectedTextColor = LightGray,
                                indicatorColor = Green.copy(alpha = 0.15f)
                            )
                        )
                    }
                }
            }
        }
    ) { padding ->
        NavHost(
            navController = navController,
            startDestination = Screen.Dashboard.route,
            modifier = Modifier.padding(padding)
        ) {
            composable(Screen.Dashboard.route) {
                val state by viewModel.dashboard.collectAsState()
                DashboardScreen(
                    state = state,
                    viewModel = viewModel,
                    onAddCall = { navController.navigate("add_call") },
                    onCloseOut = { showCloseConfirm = true }
                )
            }
            composable(Screen.Calls.route) {
                CallsScreen(
                    viewModel = viewModel,
                    onAddCall = { navController.navigate("add_call") },
                    onEditCall = { call ->
                        navController.navigate("edit_call/${call.id}")
                    }
                )
            }
            composable(Screen.Reports.route) {
                ReportsScreen(
                    viewModel = viewModel,
                    onViewDay = { dayKey ->
                        navController.navigate("day/$dayKey")
                    }
                )
            }
            composable(Screen.Expenses.route) {
                ExpensesScreen(viewModel)
            }
            composable(Screen.Settings.route) {
                SettingsScreen(viewModel)
            }
            composable("add_call") {
                AddCallScreen(
                    viewModel = viewModel,
                    onBack = { navController.popBackStack() },
                    onSaved = { navController.popBackStack() }
                )
            }
            composable(
                route = "edit_call/{callId}",
                arguments = listOf(navArgument("callId") { type = NavType.LongType })
            ) { backStack ->
                val callId = backStack.arguments?.getLong("callId") ?: 0L
                val allCalls by viewModel.allCalls.collectAsState()
                val call = allCalls.find { it.id == callId }
                if (call != null) {
                    AddCallScreen(
                        viewModel = viewModel,
                        existingCall = call,
                        onBack = { navController.popBackStack() },
                        onSaved = { navController.popBackStack() }
                    )
                }
            }
            composable(
                route = "day/{dayKey}",
                arguments = listOf(navArgument("dayKey") { type = NavType.StringType })
            ) { backStack ->
                val dayKey = backStack.arguments?.getString("dayKey") ?: ""
                DayDetailScreen(
                    dayKey = dayKey,
                    viewModel = viewModel,
                    onBack = { navController.popBackStack() },
                    onEditCall = { call ->
                        navController.navigate("edit_call/${call.id}")
                    }
                )
            }
        }
    }

    if (showCloseConfirm) {
        AlertDialog(
            onDismissRequest = { showCloseConfirm = false },
            containerColor = MediumGray,
            title = { Text("Close Out Day?", color = White, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold) },
            text = {
                Text(
                    "This will save a permanent daily summary for today. Calls remain editable. You can still add more calls after closing out.",
                    color = LightGray
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.closeOutDay()
                        showCloseConfirm = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Green)
                ) {
                    Text("CLOSE OUT", color = Black, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showCloseConfirm = false }) {
                    Text("Cancel", color = LightGray)
                }
            }
        )
    }
}
