package com.stillmantowing.earnings

import android.app.Application

class StillmanApp : Application()
