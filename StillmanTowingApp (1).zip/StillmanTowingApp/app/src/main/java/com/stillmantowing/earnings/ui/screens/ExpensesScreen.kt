package com.stillmantowing.earnings.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.stillmantowing.earnings.data.ExpenseEntity
import com.stillmantowing.earnings.ui.theme.*
import com.stillmantowing.earnings.viewmodel.MainViewModel

private val CATEGORIES = listOf("Insurance", "Fuel", "Repairs & Maintenance", "Other")

@Composable
fun ExpensesScreen(viewModel: MainViewModel) {
    val expenses by viewModel.allExpenses.collectAsState()
    val dashboard by viewModel.dashboard.collectAsState()
    var showAdd by remember { mutableStateOf(false) }

    val totalExpenses = expenses.sumOf { it.amount }
    val companyAfterDriver = dashboard.todayCompany // today's company; for overall we'd sum all
    // For overall profit estimate we use all-time company remainder approximation
    val allCalls by viewModel.allCalls.collectAsState()
    val allTimeCompany = allCalls.sumOf { it.amount * (1 - it.driverPayPercent / 100.0) }
    val estimatedProfit = allTimeCompany - totalExpenses

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkGray)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Expenses", color = White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            FloatingActionButton(
                onClick = { showAdd = true },
                containerColor = Green,
                contentColor = Black,
                modifier = Modifier.size(48.dp)
            ) {
                Icon(Icons.Default.Add, contentDescription = "Add Expense")
            }
        }

        // Summary cards
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            colors = CardDefaults.cardColors(containerColor = CardGray),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                SummaryLine("Company after driver pay (all time)", viewModel.formatCurrency(allTimeCompany))
                SummaryLine("Total Expenses", viewModel.formatCurrency(totalExpenses), orange = true)
                HorizontalDivider(color = MediumGray, modifier = Modifier.padding(vertical = 8.dp))
                SummaryLine(
                    "Estimated Profit",
                    viewModel.formatCurrency(estimatedProfit),
                    green = estimatedProfit >= 0,
                    bold = true
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        if (expenses.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("No expenses recorded yet.", color = LightGray)
            }
        } else {
            LazyColumn(
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(expenses, key = { it.id }) { expense ->
                    ExpenseCard(expense, viewModel)
                }
                item { Spacer(modifier = Modifier.height(80.dp)) }
            }
        }
    }

    if (showAdd) {
        AddExpenseDialog(
            viewModel = viewModel,
            onDismiss = { showAdd = false }
        )
    }
}

@Composable
private fun SummaryLine(
    label: String,
    value: String,
    orange: Boolean = false,
    green: Boolean = false,
    bold: Boolean = false
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, color = LightGray, fontSize = 13.sp)
        Text(
            value,
            color = when {
                orange -> Orange
                green -> Green
                else -> White
            },
            fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal,
            fontSize = if (bold) 18.sp else 14.sp
        )
    }
}

@Composable
private fun ExpenseCard(expense: ExpenseEntity, viewModel: MainViewModel) {
    Card(
        colors = CardDefaults.cardColors(containerColor = CardGray),
        shape = RoundedCornerShape(10.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(expense.category, color = White, fontWeight = FontWeight.SemiBold)
                if (expense.description.isNotBlank()) {
                    Text(expense.description, color = LightGray, fontSize = 12.sp)
                }
                Text(viewModel.formatDateTime(expense.timestamp), color = LightGray, fontSize = 11.sp)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    viewModel.formatCurrency(expense.amount),
                    color = Orange,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
                IconButton(onClick = { viewModel.deleteExpense(expense) }) {
                    Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Red)
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AddExpenseDialog(viewModel: MainViewModel, onDismiss: () -> Unit) {
    var amountText by remember { mutableStateOf("") }
    var category by remember { mutableStateOf(CATEGORIES[0]) }
    var description by remember { mutableStateOf("") }
    var expanded by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = MediumGray,
        title = { Text("Add Expense", color = White, fontWeight = FontWeight.Bold) },
        text = {
            Column {
                OutlinedTextField(
                    value = amountText,
                    onValueChange = {
                        amountText = it.filter { c -> c.isDigit() || c == '.' }
                        error = null
                    },
                    label = { Text("Amount ($)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    colors = textFieldColors(),
                    isError = error != null
                )
                if (error != null) {
                    Text(error!!, color = Red, fontSize = 12.sp)
                }
                Spacer(modifier = Modifier.height(12.dp))

                ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = it }) {
                    OutlinedTextField(
                        value = category,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Category") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .menuAnchor(),
                        colors = textFieldColors()
                    )
                    ExposedDropdownMenu(
                        expanded = expanded,
                        onDismissRequest = { expanded = false },
                        modifier = Modifier.background(CardGray)
                    ) {
                        CATEGORIES.forEach { cat ->
                            DropdownMenuItem(
                                text = { Text(cat, color = White) },
                                onClick = {
                                    category = cat
                                    expanded = false
                                }
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(12.dp))
                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("Description (optional)") },
                    modifier = Modifier.fillMaxWidth(),
                    colors = textFieldColors()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val amt = amountText.toDoubleOrNull()
                    if (amt == null || amt <= 0) {
                        error = "Enter a valid amount"
                        return@Button
                    }
                    viewModel.addExpense(amt, category, description)
                    onDismiss()
                },
                colors = ButtonDefaults.buttonColors(containerColor = Green)
            ) {
                Text("Save", color = Black, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = LightGray)
            }
        }
    )
}
